define({
  "_widgetLabel": "Header-Controller",
  "signin": "Anmelden",
  "signout": "Abmelden",
  "about": "Info",
  "signInTo": "Melden Sie sich an bei",
  "cantSignOutTip": "Diese Funktion ist im Vorschaumodus nicht zutreffend.",
  "more": "mehr"
});